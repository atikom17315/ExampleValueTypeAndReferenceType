//
//  main.cpp
//  ExampleValueTypeAndReferenceType
//
//  Created by Atikom Tancharoen on 2/20/2560 BE.
//  Copyright © 2560 Appsynth. All rights reserved.
//

#include <iostream>
using namespace std;

class Computer {
public:
    string name;
};

void showExampleOfValueTypes() {
    Computer com1 = Computer();
    com1.name = "Macbook Pro";
    
    Computer com2 = com1;
    com2.name = "Macbook Air";
    
    // step 1
    cout << "Value of com1.name: " << com1.name << endl;
    cout << "Value of com2.name: " << com2.name << endl;
    
    // step 2
    cout << "Real address of com1: " << &com1 << endl;
    cout << "Real address of com2: " << &com2 << endl;
    
    cout << endl;
}

void showExampleOfReferenceTypes() {
    Computer *com1 = new Computer();
    com1->name = "Macbook Pro";
    
    Computer *com2 = com1;
    com2->name = "Macbook Air";
    
    // step 1
    cout << "Value of com1.name: " << com1->name << endl;
    cout << "Value of com2.name: " << com2->name << endl;
    
    // step 2
    cout << "Reference address of com1: " << com1 << endl;
    cout << "Reference address of com2: " << com2 << endl;
    
    // step 3
    cout << "Real address of com1: " << &com1 << endl;
    cout << "Real address of com2: " << &com2 << endl;
    
    cout << endl;
}

int main(int argc, const char * argv[]) {
    // declaring value types by using initialize
    showExampleOfValueTypes();
    
    // declaring reference types by using operator "new"
    showExampleOfReferenceTypes();
    
    return 0;
}
