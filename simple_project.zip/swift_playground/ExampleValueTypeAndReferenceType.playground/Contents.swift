//: Playground - noun: a place where people can play

import UIKit

func address(o: UnsafeRawPointer) -> Int {
    return unsafeBitCast(o, to: Int.self)
}

func addressHeap<T: AnyObject>(o: T) -> Int {
    return unsafeBitCast(o, to: Int.self)
}


class Computer {
    var name: String = ""
}

struct Model {
    var name: String = ""
    var computer: Computer!
}

func showExampleOfValueTypes() {
    var model1 = Model()
    model1.name = "Intel"
    
    var model2 = model1
    model2.name = "AMD"
    
    print("Value of model1.name: \(model1.name)")
    print("Value of model2.name: \(model2.name)")
    
    print("Real address of model1: \(String(format: "%p", address(o: &model1)))")
    print("Real address of model2: \(String(format: "%p", address(o: &model2))) \n")
}

func showExampleOfReferenceTypes() {
    var com1 = Computer()
    com1.name = "Macbook Pro"
    
    var com2 = com1
    com2.name = "Macbook Air"
    
    print("Value of com1.name: \(com1.name)")
    print("Value of com2.name: \(com2.name)")
    
    print("Reference address of com1: \(String(format: "%p", addressHeap(o: com1)))")
    print("Reference address of com1: \(String(format: "%p", addressHeap(o: com2)))")
    
    print("Real address of com1: \(String(format: "%p", address(o: &com1)))")
    print("Real address of com1: \(String(format: "%p", address(o: &com2))) \n")
}


showExampleOfValueTypes();
showExampleOfReferenceTypes();
